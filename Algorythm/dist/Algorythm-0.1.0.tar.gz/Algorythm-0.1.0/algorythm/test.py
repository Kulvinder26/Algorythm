from Mergesort import Mergesort

A = [6,10,13,5,8,3,2,11]
print(A)
Mergesort(A,0,7)
print(A)
